import os
import cv2
import torch
from flask import Flask, request, render_template, redirect, url_for
from werkzeug.utils import secure_filename
from fpdf import FPDF
from datetime import datetime

# Define Flask app
app = Flask(__name__)

# Upload folder and allowed extensions
UPLOAD_FOLDER = 'uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# YOLOv5 model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Check if file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Object prices dictionary (same as in your code)
object_prices = {...}

# PDF generation function (same as in your code)
def generate_pdf(items_with_prices):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Billing Receipt", ln=True, align="C")
    pdf.ln(10)
    pdf.cell(60, 10, txt="Product", border=1)
    pdf.cell(40, 10, txt="Quantity", border=1)
    pdf.cell(40, 10, txt="Price", border=1)
    pdf.cell(50, 10, txt="Total", border=1)
    pdf.ln()
    total_price = 0
    for item, data in items_with_prices.items():
        quantity, price = data['quantity'], data['price']
        total = quantity * price
        pdf.cell(60, 10, txt=item, border=1)
        pdf.cell(40, 10, txt=str(quantity), border=1)
        pdf.cell(40, 10, txt=f"${price:.2f}", border=1)
        pdf.cell(50, 10, txt=f"${total:.2f}", border=1)
        pdf.ln()
        total_price += total
    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Total Price: ${total_price:.2f}", ln=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_path = "bills"
    pdf_file = os.path.join(pdf_path, f"bill_{timestamp}.pdf")
    if not os.path.exists(pdf_path):
        os.makedirs(pdf_path)
    pdf.output(pdf_file)
    return pdf_file

# Route for the homepage
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle file upload and object detection
@app.route('/submit', methods=['POST'])
def submit():
    if 'inputfile' not in request.files:
        return 'No file part'
    
    file = request.files['inputfile']
    if file.filename == '':
        return 'No selected file'
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Image processing and object detection
        img = cv2.imread(filepath)
        rgb_frame = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = model(rgb_frame)
        items_with_prices = {}
        
        for *xyxy, conf_, cls in results.xyxy[0]:
            label = results.names[int(cls)]
            price = object_prices.get(label, 0)
            if label in items_with_prices:
                items_with_prices[label]['quantity'] += 1
            else:
                items_with_prices[label] = {'quantity': 1, 'price': price}
        
        # Generate PDF
        pdf_path = generate_pdf(items_with_prices)
        
        return render_template('result.html', items=items_with_prices, pdf=pdf_path)

    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)
