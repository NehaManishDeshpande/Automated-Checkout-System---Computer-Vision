import os
import cv2
import torch
from gtts import gTTS
from playsound import playsound
from fpdf import FPDF
from datetime import datetime
from flask import Flask, request, render_template, send_file, redirect, url_for

app = Flask(__name__)

# Dictionary of objects and their prices
object_prices = {
    "person": 50.00,
    "bicycle": 150.00,
    "car": 20000.00,
    "motorcycle": 7000.00,
    "airplane": 1000000.00,
    "bus": 50000.00,
    "train": 750000.00,
    "truck": 30000.00,
    "boat": 25000.00,
    "traffic light": 300.00,
    "fire hydrant": 200.00,
    "stop sign": 50.00,
    "parking meter": 100.00,
    "bench": 150.00,
    "umbrella": 15.00,
    "handbag": 40.00,
    "tie": 20.00,
    "suitcase": 60.00,
    "frisbee": 5.00,
    "skis": 100.00,
    "snowboard": 150.00,
    "sports ball": 10.00,
    "kite": 25.00,
    "baseball bat": 20.00,
    "baseball glove": 30.00,
    "skateboard": 50.00,
    "surfboard": 200.00,
    "tennis racket": 80.00,
    "bottle": 2.00,
    "wine glass": 8.00,
    "cup": 3.00,
    "fork": 1.00,
    "knife": 1.50,
    "spoon": 1.00,
    "bowl": 5.00,
    "chair": 25.00,
    "couch": 300.00,
    "potted plant": 15.00,
    "bed": 200.00,
    "dining table": 150.00,
    "toilet": 100.00,
    "TV": 400.00,
    "laptop": 800.00,
    "mouse": 25.00,
    "remote": 15.00,
    "keyboard": 30.00,
    "cell phone": 500.00,
    "microwave": 100.00,
    "oven": 300.00,
    "toaster": 20.00,
    "sink": 75.00,
    "refrigerator": 600.00,
    "book": 10.00,
    "clock": 20.00,
    "vase": 25.00,
    "scissors": 5.00,
    "teddy bear": 15.00,
    "hair drier": 25.00,
    "toothbrush": 3.00
}

# List of animals to filter out
animals = ["dog", "cat", "bird", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe"]

model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Store detected items and prices globally
detected_items_with_prices = {}

def generate_pdf(items_with_prices):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Billing Receipt", ln=True, align="C")
    pdf.ln(10)

    pdf.cell(60, 10, txt="Product", border=1)
    pdf.cell(40, 10, txt="Quantity", border=1)
    pdf.cell(40, 10, txt="Price", border=1)
    pdf.cell(50, 10, txt="Total", border=1)
    pdf.ln()

    total_price = 0
    for item, data in items_with_prices.items():
        quantity, price = data['quantity'], data['price']
        total = quantity * price
        pdf.cell(60, 10, txt=item, border=1)
        pdf.cell(40, 10, txt=str(quantity), border=1)
        pdf.cell(40, 10, txt=f"${price:.2f}", border=1)
        pdf.cell(50, 10, txt=f"${total:.2f}", border=1)
        pdf.ln()
        total_price += total

    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Total Price: ${total_price:.2f}", ln=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_path = "bills"
    pdf_file = os.path.join(pdf_path, f"bill_{timestamp}.pdf")

    if not os.path.exists(pdf_path):
        os.makedirs(pdf_path)

    pdf.output(pdf_file)
    return pdf_file

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/capture', methods=['GET'])
def capture_image():
    video = cv2.VideoCapture(0)  # Use 0 for webcam
    ret, frame = video.read()  # Capture one frame
    video.release()

    if ret:
        image_path = "captured_image.jpg"
        cv2.imwrite(image_path, frame)  # Save the captured image
        return "Image captured successfully!"

    return "Error capturing image."



@app.route('/upload', methods=['POST'])
def upload_image():
    global detected_items_with_prices
    image = request.files['image']
    image_path = "uploaded_image.jpg"
    image.save(image_path)

    results = model(image_path)
    detections = results.pandas().xyxy[0]

    detected_items_with_prices = {}
    for _, detection in detections.iterrows():
        item = detection['name']
        if item not in animals and item in object_prices:
            if item in detected_items_with_prices:
                detected_items_with_prices[item]['quantity'] += 1
            else:
                detected_items_with_prices[item] = {'quantity': 1, 'price': object_prices[item]}

    # Just store detected items; no PDF is generated here.
    return "Image uploaded successfully!"

@app.route('/download-bill', methods=['GET'])
def download_bill():
    if not detected_items_with_prices:
        return "No items detected. Please upload an image first.", 400
    
    # Generate PDF
    pdf_file = generate_pdf(detected_items_with_prices)

    # Return the generated PDF file for download
    return send_file(pdf_file, as_attachment=True)


if __name__ == '__main__':
    app.run(debug=True)







































































































